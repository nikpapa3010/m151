<?php
function drawMietabschlussView() {
?>
    <div class="transbox">
      <h1>Reservation abgeschlossen!</h1>

      <ul class='alert alert-success'>
        <li>Die Reservation war erfolgreich!</li>
        <li>Sie werden in Kürze weitergeleitet.</li>
      </ul>
    </div>
<?php
}
?>
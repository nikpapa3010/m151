<?php
function drawKontaktView() {
?>
    <div class="transbox">

      <h4 class="pcenter">Hier können sie unsere Stand ort finden</h4>
      <p class="pcenter">
        <iframe
          src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d2725.378823502442!2d7.933501315854566!3d46.914933643492674!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x478fc136ad98c5fd%3A0xfb33990b3c17873b!2sHauptstrasse%2089%2C%206182%20Escholzmatt!5e0!3m2!1sde!2sch!4v1612703240735!5m2!1sde!2sch" 
          frameborder="0" style="border: 0; width: 100%; height: 450px;" allowfullscreen="" aria-hidden="false" tabindex="0"></iframe>
      </p>
      <br>
      <h4 class="pcenter">Firma Kontaktinformationen</h4>
      <p class="pcenter"> Adresse: Hauptstrasse 89</p>
      <p class="pcenter"> Postleitzahl: 6182 Escholzmatt</p>
      <p class="pcenter"> E-mail: JetstreamService@gmail.com</p>


    </div>
<?php
}
?>
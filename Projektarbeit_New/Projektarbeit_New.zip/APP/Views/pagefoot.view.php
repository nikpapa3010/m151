<?php
function drawPageFoot() {
?>
  </div>
</body>
</html>
<?php
}
?>
<?php
class GeneralVariables {
  public static $MainPageName = 'Jetstream-Service';
}
?>
<?php
class Mietobjekte {
  public $MietobjektID = 0;
  public $KoerpergroesseVon = 0;
  public $KoerpergroesseBis = 0;
  public $Altersgruppe = '';
  public $Geschlecht = '';
  public $PreisProTag = 0.0;
  public $BildLink = '';
  public $Objekttyp = '';
  public $ObjekttypID = 0;
}
?>
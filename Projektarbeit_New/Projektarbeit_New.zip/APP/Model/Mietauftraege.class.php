<?php
class Mietauftraege {
  public $Typ = '';
  public $Startdatum = '';
  public $Reservationsdatum = '';
  public $Dauer = 0;
  public $Status = '';
}
?>
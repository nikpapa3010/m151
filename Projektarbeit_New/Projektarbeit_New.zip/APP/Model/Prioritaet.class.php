<?php
class Prioritaet {
  public $PrioID = 0;
  public $Bezeichnung = '';
  public $Aufschlag = 0.0;
  public $Dauer = 0;
}
?>
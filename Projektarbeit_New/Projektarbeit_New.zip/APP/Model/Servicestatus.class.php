<?php
class Servicestatus {
  public $StatusID = 0;
  public $Bezeichnung = '';
  public $AnzeigenInView = false;
  public $AnzeigenInWarenkorb = false;
  public $bearbeitbar = false;
}
?>
<?php
class Benutzer_Mietauftrag {
  public $MAID = 0;
  public $Name = '';
  public $Email = '';
  public $Miete = '';
  public $Status = '';
  public $Reservationsdatum = '';
  public $Startdatum = '';
  public $EndDatum = '';
  public $Preis = 0.0;
  public $anzInView = false;
  public $anzInWk = false;
  public $bearbeitbar = false;
}
?>
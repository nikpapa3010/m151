<?php
class Benutzer_Rang {
  public $BenutzerID = 0;
  public $Name = '';
  public $Email = '';
  public $Telefon = '';
  public $Rang = '';
}
?>
<?php
class Rang {
  public $RangID = 0;
  public $Berechtigung = 0;
  public $Bezeichnung = '';
}
?>
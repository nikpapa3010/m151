<?php
class Mietobjekt {
  public $MietobjektID = 0;
  public $Koerpergroesse = 0;
  public $Altersgruppe = '';
  public $Geschlecht = '';
  public $PreisProTag = 0.0;
  public $ObjekttypFK = 0;
}
?>
<?php
class Serviceauftrag {
  public $ServiceauftragID = 0;
  public $Startdatum = '';
  public $StatusFK = 0;
  public $ServiceobjektFK = 0;
  public $PrioFK = 0;
  public $BenutzerFK = 0;
}
?>
<?php
class Serviceobjekt {
  public $ServiceobjektID = 0;
  public $Bezeichnung = '';
  public $Grundpreis = 0.0;
}
?>
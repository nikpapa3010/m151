<?php
class Benutzer_Serviceauftrag {
  public $SAID = 0;
  public $Name = '';
  public $Email = '';
  public $Service = '';
  public $Preis = 0.0;
  public $Status = '';
  public $Prioritaet = '';
  public $Startdatum = '';
  public $EndDatum = '';
  public $anzInView = false;
  public $anzInWk = false;
  public $bearbeitbar = false;
}
?>
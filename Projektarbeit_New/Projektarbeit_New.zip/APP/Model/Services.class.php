<?php
class Services {
  public $Service = '';
  public $Grundpreis = 0.0;
  public $Status = '';
  public $Prioritaet = '';
  public $Startdatum = '';
  public $Dauer = 0;
}
?>
<?php
class Mietobjekttyp {
  public $ObjekttypID = 0;
  public $Bezeichnung = '';
}
?>
<?php
class Benutzer {
  public $BenutzerID = 0;
  public $Passwort = '';
  public $Telefon = '';
  public $Email = '';
  public $Vorname = '';
  public $Nachname = '';
  public $RangFK = 0;
}
?>
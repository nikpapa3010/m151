<?php
class Benutzer_Berechtigung {
  public $Passwort = '';
  public $Berechtigung = 0;
  public $Email = '';
  public $Name = '';
}
?>